// Import all the channels to be used by Action Cable
import "channels/notification_channel";
